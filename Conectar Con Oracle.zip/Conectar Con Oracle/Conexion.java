package dal; // Clase que nos devuelve la conexion con el proveedor que se desee

import java.sql.Connection;
import java.sql.DriverManager;


public class Conexion
{
    
   public static synchronized Connection obtenerConexion() {
        Connection cn = null;
        try 
        {   
           Class.forName("oracle.jdbc.OracleDriver");          
           cn = DriverManager.getConnection("jdbc:oracle:thin:@TuHost:TuPuerto:TuBD", "ApiRest_DB","xxxx");
        }
        catch (Exception ex) 
        {
            cn = null;
        }
        finally
        {
            return cn;
        }
    }
}
