package dal; // Clase que nos devuelve la conexion con el proveedor que se desee

import java.sql.Connection;
import java.sql.DriverManager;


public class Conexion
{
    
   public static synchronized Connection obtenerConexion() {
        Connection cn = null;
        try 
        {   
         /*   Class.forName("org.mariadb.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mariadb://localhost/Api_Rest_DB","root","root");  */
           Class.forName("oracle.jdbc.OracleDriver");          
           cn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "SIMIDB","tiger");
        }
        catch (Exception ex) 
        {
            cn = null;
        }
        finally
        {
            return cn;
        }
    }
}
