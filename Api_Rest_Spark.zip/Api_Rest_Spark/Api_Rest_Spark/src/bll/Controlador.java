package bll; // Este es el Controlador Manager general de todo el sistema. Todo tiene que pasar por esta clase

import bo.Usuario;
import dal.IAccesoDatos;
import java.util.List;

public class Controlador {
    
    private IAccesoDatos _accesoDatos; 
    
    public Controlador(IAccesoDatos accesoDatos)
    {
       _accesoDatos = accesoDatos;
    }
    
    public List<Usuario> obtenerListadoUsuarios()
    {
       return _accesoDatos.obtenerListadoUsuarios();
    }
    
    public Usuario obtenerUsuario(int usuario_id)
    {
       return  _accesoDatos.obtenerUsuario(usuario_id);
    }
    
    public int guardarUsuario(Object objeto) 
    {   
        return _accesoDatos.guardarUsuario((Usuario) objeto);        
    }
    
    public int eliminarUsuario(int usuario_id)
    {
        return _accesoDatos.eliminarUsuario(usuario_id);
    }
 
}
