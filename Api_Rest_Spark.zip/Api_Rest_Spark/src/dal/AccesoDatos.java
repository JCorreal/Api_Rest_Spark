package dal; // DAL: Data Access Layer - Capa Acceso Datos con MySQL

import bo.Usuario;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AccesoDatos implements IAccesoDatos{
   private  CallableStatement cst;  // Procedimientos Almacenados
   private  ResultSet rset;         // Cursor
   private  Connection con;         // Alias para la Conexión 
   
  
   @Override
    public List<Usuario> obtenerListadoUsuarios()
    {        
     List<Usuario> listaUsuarios  = new ArrayList<>();
     try
     {  
       con = Conexion.obtenerConexion(); 
       cst = con.prepareCall("{call spr_Listados(?)}");
       cst.setInt(1, 0);
       rset = cst.executeQuery();
        while(rset.next())
        {               
              Usuario usuario = new Usuario();      
              usuario.setUsuario_id(Integer.parseInt(rset.getString(1)));
              usuario.setNombres(rset.getString(2));
              usuario.setApellidos(rset.getString(3));
              listaUsuarios.add(usuario);
        }
        rset.close();
     }             
     catch (SQLException ex) 
     {
        System.out.println("Error : " +ex);
        liberarRecursos();
     }
     catch (Exception ex) 
     {
        System.out.println("Error : " +ex);
        liberarRecursos();
     }
     finally
     {
        liberarRecursos();
     }
     return listaUsuarios;   
    }   
    
   @Override
    public Usuario obtenerUsuario(int usuario_id)
    {     
      Usuario usuario = new Usuario();
      try
      {  
        con = Conexion.obtenerConexion(); 
        cst = con.prepareCall("{call spr_Listados(?)}");
        cst.setInt(1, usuario_id);
        rset = cst.executeQuery();
        while(rset.next())
        {                     
              usuario.setUsuario_id(Integer.parseInt(rset.getString(1)));
              usuario.setNombres(rset.getString(2));
              usuario.setApellidos(rset.getString(3));        
        }
        rset.close();  
      }     
      catch (SQLException ex) 
      {
        System.out.println("Error : " +ex);
        liberarRecursos();
      }
      catch (Exception ex) 
      {
        System.out.println("Error : " +ex);
        liberarRecursos();
      }
      finally
      {
        liberarRecursos();
      }
      return usuario;
    }
   
   @Override
    public synchronized int guardarUsuario(Usuario usuario) 
    {
        int resultado = -1;
          try {
              con=Conexion.obtenerConexion();           
              cst = con.prepareCall("{call spr_IUUsuarios (?, ?, ?, ?)}");                  
              cst.setInt(1, usuario.getUsuario_id());
              cst.setString(2, usuario.getNombres());
              cst.setString(3, usuario.getApellidos());             
              cst.registerOutParameter(4, java.sql.Types.INTEGER);
              cst.executeUpdate();
              resultado = cst.getByte(4);           
          }
          catch (SQLException ex) {
              System.out.println("Error : " +ex);            
          } 
          catch (Exception ex) {
              System.out.println("Error : " +ex);            
          } 
          finally{
                   liberarRecursos();
              }
           return resultado;
      }
    
   @Override
    public synchronized int eliminarUsuario(int usuario_id) 
    {
        int resultado = -1;
           try
           {            
            con=Conexion.obtenerConexion();
            cst = con.prepareCall("{call spr_DUsuario (?,?)}");
            cst.setInt(1, usuario_id);            
            cst.registerOutParameter(2,java.sql.Types.INTEGER);
            cst.execute();
            resultado = cst.getByte(2);           
           }           
           catch (SQLException ex) {
           System.out.println("Error: " +ex);
           liberarRecursos();
           }
           catch (Exception ex) {
           System.out.println("Error: " +ex);
           liberarRecursos();
           }
           finally{
	      liberarRecursos();
	    } 
           return resultado;
      }
    
 private synchronized void liberarRecursos()          
  { // Garantizar que se cierren todos los objetos asociados a la Conexion
        try {            
            cst.close();
            con.close();            
        } catch (Exception ex) {
           System.out.println("Error Liberando Recursos: " +ex);           
        }              
  }   

}
