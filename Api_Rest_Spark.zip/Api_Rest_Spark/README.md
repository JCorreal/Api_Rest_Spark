# Api_Rest_Spark
Api Rest Java con libreria Spark y MariaDB

El mismo rest que se construyó con la librería Jersey Jackson, ahora lo hacemos pero con Spark, haremos uso de la misma BD y las mismas capas MVC del ejemplo ya realizado anteriormente con Jersey.
